geekomapia
==========

This repo is for geekomapia codebase
<br/>
Steps To Insatall.<br/>
1> Create A DataBase <br/>
2> Open installer.php <br/>
3> Fill the required details. <br/>